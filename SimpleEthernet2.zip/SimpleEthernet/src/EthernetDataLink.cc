

#include "EthernetDataLink.h"
#include "EthernetFrames_m.h"
#include "ApplicationPackets_m.h"




Define_Module(EthernetDataLink);

void EthernetDataLink::initialize()
{
    lowerLayerIn = gate("lowerLayerIn");
    upperLayerIn = gate("upperLayerIn");
    cModule *parent = getParentModule();
    //puntatore al modulo che ci conterrà e da cui otteniamo il full name
    srcName = parent->getFullPath().c_str();
}

void EthernetDataLink::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    if(msg->getArrivalGate() == upperLayerIn)
    {
        DataPacket *pkt = check_and_cast<DataPacket*>(msg);
        //il messaggio è arrivato da sopra, dobbiamo estrarre le control info
        DataControlInfo *ci = dynamic_cast<DataControlInfo*>(msg->removeControlInfo());
        if(ci == nullptr){
            error("Mancano le control info");
        }
        EthernetFrame *frame = new EthernetFrame("EthernetFrame");
        frame->setDst(ci->getDestination());
        frame->setSrc(srcName);
        // facciamo l 'incapsulamento
        frame->encapsulate(pkt);
        //inviare la frame a livello sotto
        send(frame, "lowerLayerOut");
        delete ci;
        return;
    }
    EthernetFrame *et = check_and_cast<EthernetFrame*>(msg);
    if( strcmp(et->getDst(),srcName) !=0 && strcmp(et->getDst(),"broadcast") != 0){
        //la frame non è per noi
        delete et;
        return;
    }

    EV_DEBUG << "Ricevuta frame da " << et->getSrc() << "di dim" << et->getByteLength() << "Bytes" << endl;
    cPacket *rxpkt = et->decapsulate();
     delete et;
     send(rxpkt, "upperLayerOut");


}
