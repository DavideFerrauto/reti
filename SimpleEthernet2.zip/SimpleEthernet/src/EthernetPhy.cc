
#include "EthernetPhy.h"
#include "EthernetFrames_m.h"

Define_Module(EthernetPhy);

void EthernetPhy::initialize()
{
    // TODO - Generated method body
    datarate = par ("datarate");
    txState= TX_IDLE_STATE;
    //ci serve una coda di pacchetti, in modo statico
    upperLayerIn = gate("upperLayerIn");
}

void EthernetPhy::handleMessage(cMessage *msg)
{
    if(msg->isSelfMessage())
    {
        if(strcmp(msg->getName(),"TxTimer") == 0)
        {

           EthernetFrame *frame = check_and_cast<EthernetFrame*>(msg->removeControlInfo());

            delete msg;
            send(frame, "channelOut");
            cMessage *ifgTimer = new cMessage("IFGTimer");
            scheduleAt(simTime()+SimTime(96/datarate), ifgTimer); //96= 12 byte per 8
            txState= TX_IFG_STATE;
            return;
            //manca la gestione timer ifg
        }else if(strcmp(msg->getName(), "IFGTimer")==0){
            delete msg;
            checkAndTrasmit();
            return;
        }
    }

    // arriva un pacchetto, controllare se arriva da sopra o sotto
    //possiamo fare un casting a cPacket generico
    EthernetFrame *frame = check_and_cast<EthernetFrame*>(msg);

    if(frame->getArrivalGate() == upperLayerIn)
    {
            //controllare lo stato in cui siamo
        if(txState == TX_IDLE_STATE)
        {
            //se era libero, possiamo avviare la trasmissione e avviare il timer

            /*cMessage *txTimer = new cMessage("TxTimer");
            double txt = (double)frame->getBitLength()/(double)datarate;
            scheduleAt(simTime()+(SimTime(txt)), txTimer);
            txTimer.setControlInfo(frame);
            txState= TX_TX_STATE;
             */
            checkAndTrasmit();
            return;

        }
        txQueue.insert(frame);
        return;
    }
    send(frame, "upperLayerOut");
}

 void EthernetPhy::checkAndTrasmit()
 {
     if(!txQueue.isEmpty())
     {
                     EthernetFrame *frame = check_and_cast<EthernetFrame*>(txQueue.pop());
                     cMessage *txTimer = new cMessage("TxTimer");
                     double txt = (double)frame->getBitLength()/(double)datarate;
                     scheduleAt(simTime()+(SimTime(txt)), txTimer);
                     txTimer->setControlInfo(frame);

                     txState= TX_TX_STATE;
     }else{
         txState= TX_IDLE_STATE;
     }
 }
