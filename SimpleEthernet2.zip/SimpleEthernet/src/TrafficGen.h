

#ifndef __SIMPLEETHERNET_TRAFFICGEN_H_
#define __SIMPLEETHERNET_TRAFFICGEN_H_

#include <omnetpp.h>

using namespace omnetpp;

/**
 * TODO - Generated class
 */
class TrafficGen : public cSimpleModule
{
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

    //funzione appena richiamate trasmetto l'intero burst di dati
    virtual void generate();
    //ci serve un timer per dettare i periodi di volta in volta, solitamente sono dei messaggi
    cMessage *txTimer;

    //definire 2 segnali
    simsignal_t sigE2edelay; //end to end delay pre il singolo burst e frame
    simsignal_t sigBurstE2edelay;
    simsignal_t sigThroughput;

    uint64_t totBit; //intero unsigned a 64 bit
};

#endif
