//h this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __SIMPLEETHERNET_ETHERNETDATALINK_H_
#define __SIMPLEETHERNET_ETHERNETDATALINK_H_

#include <omnetpp.h>

using namespace omnetpp;

/**
 * TODO - Generated class
 */
class EthernetDataLink : public cSimpleModule
{
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

  protected:
    cGate *lowerLayerIn;
    cGate *upperLayerIn;
    const char *srcName;
};

#endif
