

#include "TrafficGen.h"
#include "ApplicationPackets_m.h"
Define_Module(TrafficGen);

void TrafficGen::initialize() // questa parte appena parte il simulatore, setta tutti i parametri
{
    simtime_t st = par("startTime");
    //i parametri si leggono con par(nomeparametro)
    if(st >= 0)
    {
        // è un nodo trasmettitore e dobbiamo impostare lo scheduler
        txTimer = new cMessage("txTimer");
        //adesso dobbiamo schedulare il timer, ovvero il tempo di trasmissione
        scheduleAt(st, txTimer); //Ogni modulo ha vita propria
        //non è  un simulatore tempo continuo, i messaggi sono ordinati in tempo crescente nella schedulazione
        //estratti in ordine crescente
    }
    //else non facciamo nulla

     sigE2edelay = registerSignal("E2edelay");
     sigBurstE2edelay = registerSignal("E2edelayBurst");;
     sigThroughput = registerSignal("Throughput");;

     totBit=0;

}

void TrafficGen::handleMessage(cMessage *msg)
{
    // è un messaggio autogenerato?
    if(msg->isSelfMessage()){
        //potremmo avere piu timer, confrontare che il nome sia quello dato da noi
        if(strcmp(msg->getName(),"txTimer") == 0 ) //siamo in presenza di un timer
        {
            //si chiama il metodo trasmit per inviare i pacchetti
            generate();
            //rischedulare il timer di trasmissione
            scheduleAt(simTime()+ par("period"), msg);  // simTime da il tempo corrente.
            return;
        }
    }

    DataPacket *pkt = check_and_cast< DataPacket *>(msg); // casting --template

    if(strcmp(pkt->getName(), par("flow").stringValue()) != 0)
    {
        delete pkt;
        return;
    }

    double delay = (simTime()-pkt->getGenTime()).dbl();
    emit(sigE2edelay,delay);  //emettere il segnale

    totBit += pkt->getBitLength();
    double thr = (double)totBit/simTime().dbl(); // per farsi tronare il double dbl
    emit(sigThroughput,thr);

    if(pkt->getLastBurstPacket())
    {
            delay = (simTime()- pkt->getGenTime()).dbl();
            emit(sigBurstE2edelay,delay);  //emettere il segnale
    }
    //distruggere il messaggio
    delete pkt;
}

void TrafficGen::generate(){
    // quando generiamo un burst di messaggi
    // possiamo passare piu informazioni,
    //1)definire il messaggio applicativo,
    //2)un messaggio da agganciare all'applicativo che trasporta le informazioni per il livello sottostante
    DataPacket *pkt;
    DataControlInfo *ci;
    int i;
    int burst = par ("burstSize");

    for(i=0;i<burst;i++)
    {
        pkt = new DataPacket(par("flow").stringValue()); //casting esplicito quando par torna le stringhe
        pkt->setGenTime(simTime());
        if( i == (burst-1))
        {
            pkt->setLastBurstPacket(true);
        }
        pkt->setByteLength(par("payloadLength"));

        ci = new DataControlInfo();
        ci->setDestination(par("destination").stringValue());

        pkt->setControlInfo(ci);
        send(pkt,"lowerLayerOut");

    }

}
