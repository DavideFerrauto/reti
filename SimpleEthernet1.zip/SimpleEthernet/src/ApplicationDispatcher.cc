

#include "ApplicationDispatcher.h"

Define_Module(ApplicationDispatcher);

void ApplicationDispatcher::initialize()
{
    // TODO - Generated method body
}

void ApplicationDispatcher::handleMessage(cMessage *msg)
{
    //se arriva un messaggio dall upperlayerin
    if(strcmp(msg->getArrivalGate()->getBaseName(), "upperLayerIn") == 0  )  //torna un puntatore get Arrival Gate
    {
        send(msg , "lowerLayerOut");
    }else // è arrivato da sotto - creare un ciclo for e contare quanti gate abbiamo sopra
    {
        for(int i=0; i< gateSize("upperLayerOut");i++)
        {
            //dobbiamo mandare il messaggio-- owned message(appartengono al modulo) -- trasmettiamo un duplicato
            send(msg->dup(),"upperLayerOut", i);
        } //stare attenti perche rimane una copia del messaggio, dobbiamo premurarci di eliminarla

        delete msg;
    }
}
