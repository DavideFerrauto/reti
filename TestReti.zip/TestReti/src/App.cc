

#include "App.h"

Define_Module(App);

void App::initialize()
{
    // TODO - Generated method body
    cMessage *msg= new cMessage("Prova");
    //send(msg,"gout"); //ho creato un messaggio e l ho schedulato per essere trasmesso, all'istante zero
    sendDelayed(msg, 2.0,"gout"); //lo vedremo schedulato al tempo 2, se tra 0 e 2 non c è nulla , arriva li direttamnte
}

void App::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    //per stampare un mess nell interfaccia grafica, tramite redirect
    EV << "Ho ricevuto il messaggio:" << msg->getName() << endl;
}
